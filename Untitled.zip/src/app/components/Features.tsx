const features = [
  {
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
        <circle cx="24" cy="24" r="20" stroke="#6dbf5f" strokeWidth="2" />
        <path d="M8 24h32M24 8v32" stroke="#6dbf5f" strokeWidth="2" strokeLinecap="round" />
        <circle cx="24" cy="24" r="6" stroke="#6dbf5f" strokeWidth="2" />
      </svg>
    ),
    title: "Открытый Мир",
    description:
      "Огромные карты без границ. Исследуй леса, города, горы и пустыни. Полная свобода передвижения и тактики.",
  },
  {
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
        <rect x="6" y="28" width="36" height="12" rx="2" stroke="#6dbf5f" strokeWidth="2" />
        <rect x="14" y="20" width="20" height="10" rx="1" stroke="#6dbf5f" strokeWidth="2" />
        <rect x="20" y="14" width="8" height="8" stroke="#6dbf5f" strokeWidth="2" />
        <circle cx="12" cy="40" r="4" stroke="#6dbf5f" strokeWidth="2" />
        <circle cx="36" cy="40" r="4" stroke="#6dbf5f" strokeWidth="2" />
      </svg>
    ),
    title: "Военная Техника",
    description:
      "Более 10 видов техники: танки, БТР, вертолёты, самолёты, джипы и тяжёлая артиллерия. Реалистичное управление.",
  },
  {
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
        <path d="M24 4L4 14v20l20 10 20-10V14L24 4z" stroke="#6dbf5f" strokeWidth="2" strokeLinejoin="round" />
        <path d="M24 4v30M4 14l20 10 20-10" stroke="#6dbf5f" strokeWidth="2" />
      </svg>
    ),
    title: "Тактические Бои",
    description:
      "Строй укрепления, организуй засады, командуй отрядом. Каждое сражение требует уникального тактического подхода.",
  },
  {
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
        <path d="M24 8c-8.84 0-16 7.16-16 16s7.16 16 16 16 16-7.16 16-16S32.84 8 24 8z" stroke="#6dbf5f" strokeWidth="2" />
        <path d="M14 20l6 4-6 4M34 20l-6 4 6 4" stroke="#6dbf5f" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M20 32l8-16" stroke="#6dbf5f" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    title: "Система Оружия",
    description:
      "Автоматы, снайперские винтовки, гранатомёты и тяжёлое вооружение. Улучшай снаряжение и настраивай стиль боя.",
  },
  {
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
        <path d="M8 16h32v24H8z" stroke="#6dbf5f" strokeWidth="2" strokeLinejoin="round" />
        <path d="M16 16V10a8 8 0 0116 0v6" stroke="#6dbf5f" strokeWidth="2" strokeLinecap="round" />
        <circle cx="24" cy="28" r="4" stroke="#6dbf5f" strokeWidth="2" />
      </svg>
    ),
    title: "Захват Баз",
    description:
      "Захватывай стратегические точки, удерживай позиции и контролируй территорию. Побеждает тот, кто умнее.",
  },
];

export function Features() {
  return (
    <section id="features" className="relative bg-[#050505] py-24 overflow-hidden">
      {/* Background pattern */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, #6dbf5f 0px, #6dbf5f 1px, transparent 1px, transparent 20px), repeating-linear-gradient(-45deg, #6dbf5f 0px, #6dbf5f 1px, transparent 1px, transparent 20px)",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6 md:px-12">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-4">
          <div className="w-1 h-10 bg-[#6dbf5f]" />
          <h2
            className="text-white uppercase tracking-widest"
            style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "clamp(1.2rem, 3vw, 2rem)", fontWeight: 700 }}
          >
            ОСОБЕННОСТИ ИГРЫ
          </h2>
        </div>
        <p
          className="text-gray-500 mb-16 ml-5 uppercase tracking-widest text-xs"
          style={{ fontFamily: "'Share Tech Mono', monospace" }}
        >
          // ЧТО ДЕЛАЕТ TYREBOX УНИКАЛЬНОЙ
        </p>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="relative group border border-[#6dbf5f]/20 bg-black/60 p-6 hover:border-[#6dbf5f]/60 transition-all duration-300 hover:bg-[#6dbf5f]/5"
            >
              {/* Top left corner accent */}
              <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-[#6dbf5f] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-[#6dbf5f] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Icon */}
              <div className="mb-4 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>

              {/* Title */}
              <h3
                className="text-white mb-3 uppercase tracking-widest"
                style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "0.85rem", fontWeight: 700 }}
              >
                {feature.title}
              </h3>

              {/* Description */}
              <p
                className="text-gray-400 leading-relaxed"
                style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1rem" }}
              >
                {feature.description}
              </p>

              {/* Bottom green line on hover */}
              <div className="absolute bottom-0 left-0 h-px w-0 bg-[#6dbf5f] group-hover:w-full transition-all duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
import logoImg from "figma:asset/369d4d473e07f077a045db1dadb55a91d38dd74f.png";
import { useState } from "react";

export function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const links = [
    { label: "ГЛАВНАЯ", href: "#hero" },
    { label: "ОБ ИГРЕ", href: "#about" },
    { label: "ОСОБЕННОСТИ", href: "#features" },
    { label: "МЕДИА", href: "#media" },
    { label: "СКАЧАТЬ", href: "#download" },
  ];

  return (
    <nav
      style={{ fontFamily: "'Rajdhani', sans-serif" }}
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-3"
      role="navigation"
    >
      {/* Background blur */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md border-b border-[#4a7c3f]/40" />

      {/* Logo */}
      <a href="#hero" className="relative flex items-center gap-3 group">
        <img src={logoImg} alt="Tyrebox Logo" className="w-10 h-10 object-contain" />
        <span
          className="text-white tracking-widest uppercase"
          style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "1.1rem", fontWeight: 700 }}
        >
          TYREBOX
        </span>
      </a>

      {/* Desktop Links */}
      <ul className="relative hidden md:flex items-center gap-8">
        {links.map((link) => (
          <li key={link.href}>
            <a
              href={link.href}
              className="text-gray-300 hover:text-[#6dbf5f] transition-colors duration-200 tracking-widest text-sm"
              style={{ fontWeight: 600 }}
            >
              {link.label}
            </a>
          </li>
        ))}
      </ul>

      {/* CTA button */}
      <a
        href="#download"
        className="relative hidden md:block px-5 py-2 text-sm tracking-widest text-black bg-[#6dbf5f] hover:bg-[#82d972] transition-colors duration-200 uppercase"
        style={{ fontFamily: "'Orbitron', sans-serif", fontWeight: 700, clipPath: "polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)" }}
      >
        ИГРАТЬ
      </a>

      {/* Mobile Menu Button */}
      <button
        className="relative md:hidden text-white p-2"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Toggle menu"
      >
        <div className="w-6 h-0.5 bg-[#6dbf5f] mb-1.5 transition-all" style={{ transform: menuOpen ? "rotate(45deg) translate(3px, 6px)" : "none" }} />
        <div className="w-6 h-0.5 bg-[#6dbf5f] mb-1.5 transition-all" style={{ opacity: menuOpen ? 0 : 1 }} />
        <div className="w-6 h-0.5 bg-[#6dbf5f] transition-all" style={{ transform: menuOpen ? "rotate(-45deg) translate(3px, -6px)" : "none" }} />
      </button>

      {/* Mobile Dropdown */}
      {menuOpen && (
        <div className="absolute top-full left-0 right-0 bg-black/95 border-b border-[#4a7c3f]/40 flex flex-col items-center gap-4 py-6">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="text-gray-300 hover:text-[#6dbf5f] tracking-widest text-sm uppercase"
              style={{ fontWeight: 600 }}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#download"
            onClick={() => setMenuOpen(false)}
            className="mt-2 px-6 py-2 text-sm tracking-widest text-black bg-[#6dbf5f] hover:bg-[#82d972] uppercase"
            style={{ fontFamily: "'Orbitron', sans-serif", fontWeight: 700 }}
          >
            ИГРАТЬ
          </a>
        </div>
      )}
    </nav>
  );
}

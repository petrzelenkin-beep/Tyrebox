import logoImg from "figma:asset/369d4d473e07f077a045db1dadb55a91d38dd74f.png";

export function Download() {
  return (
    <section id="download" className="relative bg-[#050505] py-24 overflow-hidden">
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(109,191,95,0.08) 0%, transparent 70%)",
        }}
      />

      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(#6dbf5f 1px, transparent 1px), linear-gradient(90deg, #6dbf5f 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative max-w-4xl mx-auto px-6 md:px-12 text-center">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div
              className="absolute inset-0 blur-2xl opacity-30 rounded-full"
              style={{ backgroundColor: "#6dbf5f" }}
            />
            <img
              src={logoImg}
              alt="Tyrebox"
              className="relative w-28 h-28 object-contain"
            />
          </div>
        </div>

        {/* Title */}
        <h2
          className="text-white uppercase tracking-widest mb-4"
          style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "clamp(1.5rem, 5vw, 3rem)", fontWeight: 900 }}
        >
          ГОТОВ К БОЮ?
        </h2>

        {/* Divider */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <div className="h-px w-20 bg-[#6dbf5f]/60" />
          <span
            className="text-[#6dbf5f] text-xs tracking-widest uppercase"
            style={{ fontFamily: "'Share Tech Mono', monospace" }}
          >
            TYREBOX 2026
          </span>
          <div className="h-px w-20 bg-[#6dbf5f]/60" />
        </div>

        <p
          className="text-gray-400 mb-12 leading-relaxed max-w-xl mx-auto"
          style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.1rem" }}
        >
          Присоединяйся к тысячам игроков. Tyrebox доступна бесплатно — начни своё военное
          приключение прямо сейчас!
        </p>

        {/* Download buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          {/* Primary - Play button */}
          <a
            href="#"
            className="group relative inline-flex items-center justify-center gap-3 px-10 py-5 text-black uppercase tracking-widest transition-all duration-200 hover:scale-105"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              fontWeight: 700,
              fontSize: "1rem",
              backgroundColor: "#6dbf5f",
              clipPath: "polygon(16px 0%, 100% 0%, calc(100% - 16px) 100%, 0% 100%)",
              boxShadow: "0 0 40px rgba(109,191,95,0.5)",
            }}
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="flex-shrink-0"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
            ИГРАТЬ БЕСПЛАТНО
          </a>

          {/* Telegram */}
          <a
            href="https://t.me/Tyrebox_official"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-3 px-10 py-5 text-white uppercase tracking-widest border border-white/20 hover:border-[#6dbf5f]/60 hover:text-[#6dbf5f] transition-all duration-200"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              fontWeight: 700,
              fontSize: "0.85rem",
              clipPath: "polygon(16px 0%, 100% 0%, calc(100% - 16px) 100%, 0% 100%)",
            }}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" className="flex-shrink-0">
              <path d="M11.944 0A12 12 0 000 12a12 12 0 0012 12 12 12 0 0012-12A12 12 0 0012 0a12 12 0 00-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 01.171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
            </svg>
            TELEGRAM
          </a>
        </div>

        {/* Platform badges */}
        <div className="flex flex-wrap items-center justify-center gap-6">
          {["WINDOWS", "MAC OS", "LINUX"].map((platform) => (
            <div
              key={platform}
              className="flex items-center gap-2"
            >
              <div className="w-2 h-2 bg-[#6dbf5f] rotate-45" />
              <span
                className="text-gray-500 text-xs tracking-widest uppercase"
                style={{ fontFamily: "'Share Tech Mono', monospace" }}
              >
                {platform}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
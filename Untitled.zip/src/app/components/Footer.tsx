import logoImg from "figma:asset/369d4d473e07f077a045db1dadb55a91d38dd74f.png";

export function Footer() {
  const links = [
    { label: "Главная", href: "#hero" },
    { label: "Об игре", href: "#about" },
    { label: "Особенности", href: "#features" },
    { label: "Медиа", href: "#media" },
    { label: "Скачать", href: "#download" },
  ];

  const socials = [
    {
      label: "Telegram",
      href: "https://t.me/Tyrebox_official",
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.944 0A12 12 0 000 12a12 12 0 0012 12 12 12 0 0012-12A12 12 0 0012 0a12 12 0 00-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 01.171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
        </svg>
      ),
    },
    {
      label: "TikTok",
      href: "#",
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.75a8.17 8.17 0 004.78 1.52V6.82a4.85 4.85 0 01-1.01-.13z" />
        </svg>
      ),
    },
  ];

  return (
    <footer className="relative bg-black border-t border-[#6dbf5f]/20 py-12">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logoImg} alt="Tyrebox" className="w-10 h-10 object-contain" />
              <span
                className="text-white tracking-widest uppercase"
                style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "1rem", fontWeight: 700 }}
              >
                TYREBOX
              </span>
            </div>
            <p
              className="text-gray-500 leading-relaxed text-sm"
              style={{ fontFamily: "'Rajdhani', sans-serif" }}
            >
              Военная песочница с открытым миром. Сражайся, захватывай, побеждай.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4
              className="text-[#6dbf5f] uppercase tracking-widest text-xs mb-4"
              style={{ fontFamily: "'Share Tech Mono', monospace" }}
            >
              // НАВИГАЦИЯ
            </h4>
            <ul className="space-y-2">
              {links.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-gray-500 hover:text-[#6dbf5f] transition-colors text-sm tracking-wider uppercase"
                    style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 600 }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4
              className="text-[#6dbf5f] uppercase tracking-widest text-xs mb-4"
              style={{ fontFamily: "'Share Tech Mono', monospace" }}
            >
              // СОЦИАЛЬНЫЕ СЕТИ
            </h4>
            <div className="flex flex-wrap gap-3">
              {socials.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 flex items-center justify-center border border-[#6dbf5f]/30 text-gray-400 hover:text-[#6dbf5f] hover:border-[#6dbf5f]/60 transition-all duration-200"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[#6dbf5f]/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span
            className="text-gray-600 text-xs tracking-wider"
            style={{ fontFamily: "'Share Tech Mono', monospace" }}
          >
            © 2026 TYREBOX. ВСЕ ПРАВА ЗАЩИЩЕНЫ.
          </span>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#6dbf5f] animate-pulse" />
            <span
              className="text-[#6dbf5f] text-xs tracking-widest uppercase"
              style={{ fontFamily: "'Share Tech Mono', monospace" }}
            >
              SERVERS ONLINE
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
import { ImageWithFallback } from "./figma/ImageWithFallback";

const TANK_URL =
  "https://images.unsplash.com/photo-1564549160217-7a01514d2fda?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxpdGFyeSUyMHRhbmslMjBvcGVuJTIwZmllbGR8ZW58MXx8fHwxNzcyMzUzODk3fDA&ixlib=rb-4.1.0&q=80&w=1080";
const HELI_URL =
  "https://images.unsplash.com/photo-1549563793-ae7c90155169?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxpdGFyeSUyMGhlbGljb3B0ZXIlMjBhcm15fGVufDF8fHx8MTc3MjM1Mzg5N3ww&ixlib=rb-4.1.0&q=80&w=1080";
const APC_URL =
  "https://images.unsplash.com/photo-1759203977871-02585c46a9c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxpdGFyeSUyMHZlaGljbGUlMjBhcm1vcmVkJTIwY2FyfGVufDF8fHx8MTc3MjM1Mzg5OHww&ixlib=rb-4.1.0&q=80&w=1080";
const SOLDIERS_URL =
  "https://images.unsplash.com/photo-1588589155304-cb0a733ec74d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcm15JTIwc29sZGllcnMlMjBzcXVhZCUyMGNvbWJhdHxlbnwxfHx8fDE3NzIzNTM5MDF8MA&ixlib=rb-4.1.0&q=80&w=1080";

const mediaItems = [
  { src: TANK_URL, label: "БРОНЕТАНКОВЫЕ СИЛЫ", span: "col-span-1 row-span-1 md:col-span-2" },
  { src: HELI_URL, label: "АВИАЦИОННАЯ ПОДДЕРЖКА", span: "col-span-1 row-span-1" },
  { src: SOLDIERS_URL, label: "ПЕХОТНЫЕ ОТРЯДЫ", span: "col-span-1 row-span-1" },
  { src: APC_URL, label: "БРОНЕТЕХНИКА", span: "col-span-1 row-span-1 md:col-span-2" },
];

export function Media() {
  return (
    <section id="media" className="relative bg-black py-24 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#6dbf5f]/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-4">
          <div className="w-1 h-10 bg-[#6dbf5f]" />
          <h2
            className="text-white uppercase tracking-widest"
            style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "clamp(1.2rem, 3vw, 2rem)", fontWeight: 700 }}
          >
            МЕДИА
          </h2>
        </div>
        <p
          className="text-gray-500 mb-16 ml-5 uppercase tracking-widest text-xs"
          style={{ fontFamily: "'Share Tech Mono', monospace" }}
        >
          // СКРИНШОТЫ И ГЕЙМПЛЕЙ
        </p>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {mediaItems.map((item) => (
            <div
              key={item.label}
              className={`relative group overflow-hidden border border-[#6dbf5f]/20 hover:border-[#6dbf5f]/60 transition-all duration-300 ${item.span}`}
            >
              <ImageWithFallback
                src={item.src}
                alt={item.label}
                className="w-full h-56 md:h-64 object-cover group-hover:scale-105 transition-transform duration-500"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              {/* Label */}
              <div className="absolute bottom-4 left-4 right-4">
                <span
                  className="text-[#6dbf5f] text-xs tracking-widest uppercase"
                  style={{ fontFamily: "'Share Tech Mono', monospace" }}
                >
                  // {item.label}
                </span>
              </div>

              {/* Corner markers */}
              <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-[#6dbf5f] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-[#6dbf5f] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#6dbf5f]/30 to-transparent" />
    </section>
  );
}

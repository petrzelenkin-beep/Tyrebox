import image_369d4d473e07f077a045db1dadb55a91d38dd74f from 'figma:asset/369d4d473e07f077a045db1dadb55a91d38dd74f.png'
import image_01567d1e75fc806155a5060af0a2a9eab139965d from 'figma:asset/01567d1e75fc806155a5060af0a2a9eab139965d.png'
import { ImageWithFallback } from "./figma/ImageWithFallback";

const LANDSCAPE_URL =
  "https://images.unsplash.com/photo-1571149819090-a29d6a1d935f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcGVuJTIwd29ybGQlMjBsYW5kc2NhcGUlMjB2YXN0JTIwdGVycmFpbiUyMGFlcmlhbHxlbnwxfHx8fDE3NzIzNTM5MDB8MA&ixlib=rb-4.1.0&q=80&w=1080";

const stats = [
  { value: "100км²", label: "Открытый мир" },
  { value: "50+", label: "Видов техники" },
  { value: "∞", label: "Тактик игры" },
  { value: "FREE", label: "Бесплатно" },
];

export function About() {
  return (
    <section id="about" className="relative bg-black py-24 overflow-hidden">
      {/* Decorative line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#6dbf5f]/60 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <div className="w-1 h-10 bg-[#6dbf5f]" />
          <h2
            className="text-white uppercase tracking-widest"
            style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "clamp(1.2rem, 3vw, 2rem)", fontWeight: 700 }}
          >
            ОБ ИГРЕ
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text side */}
          <div>
            <h3
              className="text-[#6dbf5f] uppercase tracking-widest mb-6"
              style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "0.85rem" }}
            >
              // TYREBOX — ВОЕННАЯ ПЕСОЧНИЦА С ОТКРЫТЫМ МИРОМ
            </h3>
            <p
              className="text-gray-300 mb-6 leading-relaxed"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.1rem" }}
            >
              Tyrebox — это масштабная военная игра в жанре песочницы с огромным открытым миром.
              Здесь ты можешь сам решать, как воевать: штурмовать позиции на танке, поддерживать
              пехоту с вертолёта или вести снайперскую охоту.
            </p>
            <p
              className="text-gray-400 mb-10 leading-relaxed"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.05rem" }}
            >
              Игра предоставляет полную свободу действий — изучай территорию, захватывай базы,
              управляй разнообразной военной техникой и создавай собственные тактики победы в
              бесконечных сценариях сражений.
            </p>

            {/* Stats row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="border border-[#6dbf5f]/30 bg-[#6dbf5f]/5 p-4 text-center"
                  style={{ clipPath: "polygon(8px 0%, 100% 0%, calc(100% - 8px) 100%, 0% 100%)" }}
                >
                  <div
                    className="text-[#6dbf5f] mb-1"
                    style={{ fontFamily: "'Orbitron', sans-serif", fontSize: "1.4rem", fontWeight: 700 }}
                  >
                    {stat.value}
                  </div>
                  <div
                    className="text-gray-400 uppercase text-xs tracking-wider"
                    style={{ fontFamily: "'Rajdhani', sans-serif" }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Image side */}
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-br from-[#6dbf5f]/20 to-transparent rounded-sm" />
            <div className="relative overflow-hidden border border-[#6dbf5f]/30">
              
              
              <div
                className="absolute bottom-4 left-4 text-[#6dbf5f] text-xs tracking-widest uppercase"
                style={{ fontFamily: "'Share Tech Mono', monospace" }}
              >
                // ОТКРЫТЫЙ МИР — ВАШИ ПРАВИЛА
              </div>
            </div>
            {/* Corner decorations */}
            <div className="absolute top-0 left-0 w-5 h-5 border-t-2 border-l-2 border-[#6dbf5f] -translate-x-1 -translate-y-1" />
            <div className="absolute top-0 right-0 w-5 h-5 border-t-2 border-r-2 border-[#6dbf5f] translate-x-1 -translate-y-1" />
            <div className="absolute bottom-0 left-0 w-5 h-5 border-b-2 border-l-2 border-[#6dbf5f] -translate-x-1 translate-y-1" />
            <div className="absolute bottom-0 right-0 w-5 h-5 border-b-2 border-r-2 border-[#6dbf5f] translate-x-1 translate-y-1" />
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#6dbf5f]/30 to-transparent" />
    </section>
  );
}
import logoImg from "figma:asset/369d4d473e07f077a045db1dadb55a91d38dd74f.png";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const BG_URL =
  "https://images.unsplash.com/photo-1616594418225-8721ec37fa82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxpdGFyeSUyMHdhciUyMGJhdHRsZWZpZWxkJTIwZGFya3xlbnwxfHx8fDE3NzIzNTM4OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080";

export function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={BG_URL}
          alt="Battlefield background"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/70" />
        {/* Gradient bottom */}
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black to-transparent" />
        {/* Gradient top */}
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black to-transparent" />
        {/* Green scanline effect */}
        <div
          className="absolute inset-0 opacity-5 pointer-events-none"
          style={{
            backgroundImage: "repeating-linear-gradient(0deg, #6dbf5f 0px, transparent 1px, transparent 4px)",
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-5xl mx-auto">
        {/* Logo */}
        <div className="mb-8 relative">
          <div
            className="absolute inset-0 rounded-full blur-3xl opacity-20"
            style={{ backgroundColor: "#6dbf5f" }}
          />
          <img
            src={logoImg}
            alt="Tyrebox Logo"
            className="relative w-48 h-48 md:w-64 md:h-64 object-contain drop-shadow-2xl"
          />
        </div>

        {/* Title */}
        <h1
          className="text-white mb-4 tracking-[0.3em] uppercase"
          style={{
            fontFamily: "'Orbitron', sans-serif",
            fontSize: "clamp(2.5rem, 8vw, 6rem)",
            fontWeight: 900,
            textShadow: "0 0 40px rgba(109,191,95,0.5), 0 0 80px rgba(109,191,95,0.2)",
            lineHeight: 1.1,
          }}
        >
          TYREBOX
        </h1>

        {/* Subtitle line */}
        <div className="flex items-center gap-4 mb-6">
          <div className="h-px w-16 md:w-32 bg-[#6dbf5f]" />
          <span
            className="text-[#6dbf5f] tracking-[0.5em] uppercase text-sm md:text-base"
            style={{ fontFamily: "'Share Tech Mono', monospace" }}
          >
            ВОЕННАЯ ПЕСОЧНИЦА
          </span>
          <div className="h-px w-16 md:w-32 bg-[#6dbf5f]" />
        </div>

        {/* Description */}
        <p
          className="text-gray-300 max-w-2xl mb-10 leading-relaxed text-base md:text-lg"
          style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 400 }}
        >
          Открытый мир масштабных военных операций. Управляй танками, вертолётами и бронетехникой.
          Сражайся на огромных картах, выстраивай тактику и побеждай в жестоких битвах.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <a
            href="#download"
            className="px-10 py-4 text-black uppercase tracking-widest transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              fontWeight: 700,
              fontSize: "0.9rem",
              backgroundColor: "#6dbf5f",
              clipPath: "polygon(12px 0%, 100% 0%, calc(100% - 12px) 100%, 0% 100%)",
              boxShadow: "0 0 30px rgba(109,191,95,0.4)",
            }}
          >
            ИГРАТЬ СЕЙЧАС
          </a>
          <a
            href="#about"
            className="px-10 py-4 text-[#6dbf5f] uppercase tracking-widest border border-[#6dbf5f]/60 hover:bg-[#6dbf5f]/10 transition-all duration-200"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              fontWeight: 700,
              fontSize: "0.9rem",
              clipPath: "polygon(12px 0%, 100% 0%, calc(100% - 12px) 100%, 0% 100%)",
            }}
          >
            ОБ ИГРЕ
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="mt-16 flex flex-col items-center gap-2 opacity-60 animate-bounce">
          <span className="text-xs text-gray-400 tracking-widest uppercase" style={{ fontFamily: "'Share Tech Mono', monospace" }}>
            Прокрутить вниз
          </span>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="text-[#6dbf5f]">
            <path d="M10 3v14M3 10l7 7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
    </section>
  );
}

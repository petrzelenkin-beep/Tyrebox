import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Features } from "./components/Features";
import { Media } from "./components/Media";
import { Download } from "./components/Download";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div
      className="min-h-screen bg-black"
      style={{ fontFamily: "'Rajdhani', sans-serif" }}
    >
      <Navbar />
      <Hero />
      <About />
      <Features />
      <Media />
      <Download />
      <Footer />
    </div>
  );
}
